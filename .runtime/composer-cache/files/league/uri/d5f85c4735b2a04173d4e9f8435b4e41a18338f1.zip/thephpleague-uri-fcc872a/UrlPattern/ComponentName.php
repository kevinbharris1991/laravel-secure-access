<?php

/**
 * League.Uri (https://uri.thephpleague.com)
 *
 * (c) Ignace Nyamagana Butera <nyamsprod@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

declare(strict_types=1);

namespace League\Uri\UrlPattern;

enum ComponentName: string
{
    case Scheme = 'scheme';
    case Username = 'username';
    case Password = 'password';
    case Host = 'host';
    case Port = 'port';
    case Path = 'path';
    case Query = 'query';
    case Fragment = 'fragment';
}
